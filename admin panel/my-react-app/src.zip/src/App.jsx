import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Users from "./pages/Users";
import UserDetails from "./pages/UserDetails";
import Payments from "./pages/Payments";
import Subscriptions from "./pages/Subscriptions";
import SubscriptionDetails from "./pages/SubscriptionDetails";
import Notifications from "./pages/Notifications";
import SupportTicketDetails from "./pages/SupportTicketDetails";
import ReportedProfiles from "./pages/ReportedProfiles";
  // ✅ fixed import

import SupportTickets from "./pages/SupportTickets";
import CMSPages from "./pages/CMSPages";
import FAQ from "./pages/FAQ";
import MasterData from "./pages/MasterData";
import AuditLogs from "./pages/AuditLogs";


import AdminLayout from "./components/AdminLayout";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Login */}
        <Route path="/" element={<Login />} />

        {/* Admin Panel */}
        <Route element={<AdminLayout />}>

          {/* Dashboard */}
          <Route path="/dashboard" element={<Dashboard />} />

          {/* Users */}
          <Route path="/users" element={<Users />} />
          <Route path="/users/:id" element={<UserDetails />} />

          {/* Payments */}
          <Route path="/payments" element={<Payments />} />

          {/* Subscriptions */}
          <Route path="/subscriptions" element={<Subscriptions />} />
          <Route path="/subscriptions/:id" element={<SubscriptionDetails />} />

          {/* Notifications */}
          <Route path="/notifications" element={<Notifications />} />

          {/* Support Center */}
          <Route path="/reported-profiles" element={<ReportedProfiles />} />
          <Route path="/support-tickets" element={<SupportTickets />} />
          <Route path="/faqs" element={<FAQ />} />

          {/* Analytics */}
  {/* ✅ fixed route */}

          {/* CMS */}
          <Route path="/cms-pages" element={<CMSPages />} />

          {/* Master Data */}
          <Route path="/master-data" element={<MasterData />} />

          {/* Audit Logs */}
          <Route path="/audit-logs" element={<AuditLogs />} />


        </Route>
<Route
    path="/support-tickets/:ticketNumber"
    element={<SupportTicketDetails />}
/>
        {/* Invalid URL */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
