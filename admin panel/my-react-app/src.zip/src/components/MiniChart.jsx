import React, { useRef, useState } from "react";

export default function MiniChart({
  data = [],
  width = 600,
  height = 220,
  color = "#7C3AED",
  labels = [],
}) {
  const wrapperRef = useRef(null);
  const [hoverIdx, setHoverIdx] = useState(null);

if (!data || data.length === 0) {
  return (
    <div className="h-full flex items-center justify-center text-gray-500">
      No data available
    </div>
  );
}

  const max = Math.max(...data);
  const min = Math.min(...data);

const stepX =
  data.length > 1
    ? width / (data.length - 1)
    : width / 2;

  const points = data.map((value, index) => {
    const x = index * stepX;
    const y =
      max === min
        ? height / 2
        : height - ((value - min) / (max - min)) * (height - 30) - 15;

    return { x, y, value, label: labels[index] };
  });

  const line = points.map((p) => `${p.x},${p.y}`).join(" ");

  const area = `M0,${height} L${points.map((p) => `${p.x},${p.y}`).join(" L")} L${width},${height} Z`;

  function handleMove(e) {
    const rect = wrapperRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    // convert to svg coordinate space
    const svgX = (clientX / rect.width) * width;
    const idx = Math.max(0, Math.min(data.length - 1, Math.round(svgX / stepX)));
    setHoverIdx(idx);
  }

  function handleLeave() {
    setHoverIdx(null);
  }

  return (
    <div ref={wrapperRef} className="relative w-full" style={{ height }}>
      <svg
        width="100%"
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        preserveAspectRatio="none"
        onMouseMove={handleMove}
        onMouseLeave={handleLeave}
      >
        <defs>
          <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.35" />
            <stop offset="100%" stopColor={color} stopOpacity="0.05" />
          </linearGradient>
        </defs>

        {/* Area */}
        <path d={area} fill="url(#chartFill)" />

        {/* Line */}
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="4"
          strokeLinejoin="round"
          strokeLinecap="round"
          points={line}
        />

        {/* Dots */}
        {points.map((point, index) => (
          <circle key={index} cx={point.x} cy={point.y} r="5" fill={color} stroke="white" strokeWidth="2" />
        ))}

        {/* Hover vertical line */}
        {hoverIdx !== null && (
          <line
            x1={points[hoverIdx].x}
            x2={points[hoverIdx].x}
            y1={0}
            y2={height}
            stroke="#CBD5E1"
            strokeWidth={1}
            strokeDasharray="4 4"
          />
        )}
      </svg>

      {/* Tooltip */}
      {hoverIdx !== null && (
        <div
          className="absolute -translate-x-1/2 bg-white border rounded shadow px-3 py-2 text-sm"
          style={{
            left: `${(points[hoverIdx].x / width) * 100}%`,
            top: Math.max(6, points[hoverIdx].y - 48),
            transform: "translateX(-50%)",
            pointerEvents: "none",
            minWidth: 96,
            zIndex: 50,
          }}
        >
          <div className="font-semibold text-gray-800">{points[hoverIdx].label ?? `Month ${hoverIdx + 1}`}</div>
          <div className="text-gray-600">{points[hoverIdx].value}</div>
        </div>
      )}
    </div>
  );
}