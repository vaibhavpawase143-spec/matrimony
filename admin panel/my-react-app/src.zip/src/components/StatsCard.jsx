import React from "react";
import {
  FaUsers,
  FaUserCheck,
  FaCrown,
  FaRupeeSign,
} from "react-icons/fa";

const icons = {
  users: <FaUsers size={28} />,
  active: <FaUserCheck size={28} />,
  premium: <FaCrown size={28} />,
  revenue: <FaRupeeSign size={28} />,
};

const colors = {
  users: "from-violet-500 to-purple-600",
  active: "from-blue-500 to-cyan-500",
  premium: "from-pink-500 to-rose-500",
  revenue: "from-green-500 to-emerald-500",
};

export default function StatsCard({
  title,
  value,
  type = "users",
}) {
  return (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-6">

      <div className="flex justify-between items-center">

        <div>
          <p className="text-gray-500 text-sm">
            {title}
          </p>

          <h2 className="text-3xl font-bold mt-2">
            {value}
          </h2>

          <p className="text-green-600 text-sm mt-2">
            ↑ 12% this month
          </p>
        </div>

        <div
          className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${colors[type]} text-white flex justify-center items-center`}
        >
          {icons[type]}
        </div>

      </div>

    </div>
  );
}