import React from "react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
} from "recharts";

const data = [
  {
    name: "Premium",
    value: 420,
    color: "#7C3AED",
  },
  {
    name: "Elite",
    value: 260,
    color: "#EC4899",
  },
  {
    name: "Basic",
    value: 180,
    color: "#3B82F6",
  },
  {
    name: "Free",
    value: 140,
    color: "#FBBF24",
  },
];

const total = data.reduce((sum, item) => sum + item.value, 0);

export default function SubscriptionChart({ height = 320 }) {
  const innerRadius = Math.max(40, Math.floor(height * 0.23));
  const outerRadius = Math.max(70, Math.floor(height * 0.36));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">

      {/* Donut Chart */}
      <div className="relative" style={{ height }}>

        <ResponsiveContainer width="100%" height="100%">
          <PieChart>

            <Pie
              data={data}
              dataKey="value"
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              paddingAngle={4}
            >
              {data.map((item, index) => (
                <Cell
                  key={index}
                  fill={item.color}
                />
              ))}
            </Pie>

          </PieChart>
        </ResponsiveContainer>

        {/* Center Text */}

        <div className="absolute inset-0 flex flex-col justify-center items-center">

          <p className="text-gray-500 text-sm">
            Total
          </p>

          <h2 className="text-4xl font-bold text-gray-800">
            {total}
          </h2>

          <p className="text-violet-600 font-medium">
            Subscriptions
          </p>

        </div>

      </div>

      {/* Right Side */}

      <div className="space-y-6">

        {data.map((item) => {

          const percent = ((item.value / total) * 100).toFixed(0);

          return (

            <div key={item.name}>

              <div className="flex justify-between mb-2">

                <div className="flex items-center gap-3">

                  <span
                    className="w-4 h-4 rounded-full"
                    style={{
                      backgroundColor: item.color,
                    }}
                  ></span>

                  <span className="font-semibold">
                    {item.name}
                  </span>

                </div>

                <span className="font-bold">
                  {item.value}
                </span>

              </div>

              <div className="w-full h-3 bg-gray-200 rounded-full">

                <div
                  className="h-3 rounded-full"
                  style={{
                    width: `${percent}%`,
                    backgroundColor: item.color,
                  }}
                ></div>

              </div>

              <p className="text-sm text-gray-500 mt-1">
                {percent}% of Total
              </p>

            </div>

          );
        })}

      </div>

    </div>
  );
}