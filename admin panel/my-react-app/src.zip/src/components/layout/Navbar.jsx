import { useState, useRef, useEffect } from "react";
import { FaBars, FaBell, FaUserCircle } from "react-icons/fa";

export default function Navbar({ onMenuToggle, sidebarOpen }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const menuRef = useRef(null);

  const toggleMenu = () => setMenuOpen((s) => !s);

  useEffect(() => {
    function onDocClick(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  return (
    <>
      <header className="relative h-16 sm:h-20 bg-purple-100 border-b border-purple-200 shadow-sm flex items-center justify-between px-3 sm:px-4 md:px-8 sticky top-0 z-50">


      {/* Left Section */}
      <div className="flex items-center gap-2 sm:gap-3 md:gap-5">

        <button
          onClick={onMenuToggle}
          aria-expanded={sidebarOpen}
          aria-controls="mobile-sidebar"
          className="md:hidden text-xl text-purple-900 hover:text-purple-700 transition"
        >
          <FaBars />
        </button>

        {menuOpen && (
          <div
            id="admin-menu"
            ref={menuRef}
            className="absolute top-16 sm:top-20 left-3 sm:left-4 md:left-8 bg-white border border-gray-200 rounded-lg shadow-lg p-4 w-56 sm:w-64 z-50"
          >
            <div className="flex items-center gap-3">
              <img src="https://i.pravatar.cc/48?img=12" alt="Admin" className="w-12 h-12 rounded-full object-cover" />
              <div>
                <div className="font-semibold text-gray-800">Admin</div>
                <div className="text-xs text-gray-500">admin@example.com</div>
              </div>
            </div>

            <div className="mt-3 grid gap-2">
              <button
                onClick={() => {
                  setShowProfile(true);
                  setMenuOpen(false);
                }}
                className="text-left px-2 py-2 rounded hover:bg-gray-100"
              >
                View Profile
              </button>

              <button className="text-left px-2 py-2 rounded hover:bg-gray-100">Logout</button>
            </div>
          </div>
        )}

        <img
          src="https://i.pravatar.cc/48?img=12"
          alt="Admin profile"
          onError={(e) => {
            e.currentTarget.src = "https://i.pravatar.cc/48?img=1";
          }}
          className="w-8 h-8 sm:w-9 sm:h-9 md:w-11 md:h-11 rounded-full object-cover"
        />

        <div className="hidden sm:block">
          <p className="text-xs text-gray-500">
            Welcome
          </p>

          <h2 className="text-sm md:text-2xl font-bold text-gray-800">
            Admin
          </h2>
        </div>

      </div>



      



      {/* Right Icons */}
      <div className="flex items-center gap-1 sm:gap-2 md:gap-4">


        <button
          aria-label="Notifications"
          className="w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10 p-1 sm:p-0 rounded-full bg-purple-100 hover:bg-purple-200 flex items-center justify-center transition focus:outline-none focus:ring-2 focus:ring-purple-300"
        >
          <FaBell className="text-purple-700 text-xs sm:text-base md:text-lg" />
        </button>

        <button className="w-8 h-8 sm:w-9 sm:h-9 md:w-11 md:h-11 rounded-full bg-purple-600 text-white flex items-center justify-center">
          <FaUserCircle className="text-base sm:text-lg md:text-2xl" />
        </button>


      </div>


    </header>
    {showProfile && (
      <div className="fixed inset-0 z-60 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={() => setShowProfile(false)} />

        <div className="relative bg-white rounded-lg shadow-lg w-11/12 sm:w-full max-w-md p-4 sm:p-6 z-70">
          <div className="flex items-center gap-4">
            <img src="https://i.pravatar.cc/80?img=12" alt="Admin" className="w-16 h-16 rounded-full object-cover" />
            <div>
              <div className="font-semibold text-gray-800">Admin</div>
              <div className="text-sm text-gray-500">admin@example.com</div>
            </div>
          </div>

          <div className="mt-4 space-y-2 text-sm text-gray-600">
            <div><strong>Role:</strong> Super Admin</div>
            <div><strong>Joined:</strong> 2024-01-10</div>
            <div><strong>Plan:</strong> Elite</div>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <button onClick={() => setShowProfile(false)} className="px-4 py-2 rounded bg-gray-100">Close</button>
          </div>
        </div>
      </div>
    )}
    </>
  );
}