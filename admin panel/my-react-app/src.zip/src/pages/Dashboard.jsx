import { useEffect, useState } from "react";
import Loader from "../components/Loader";
import StatsCard from "../components/StatsCard";
import MiniChart from "../components/MiniChart";
import SubscriptionChart from "../components/SubscriptionChart";
import { getDashboardStats } from "../services/dashboardService";

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    getDashboardStats().then((res) => {
      setData(res);
      setLoading(false);
    });
  }, []);

  const refreshData = () => {
    if (refreshing) return;

    setRefreshing(true);

    getDashboardStats()
      .then((res) => {
        setData(res);
      })
      .finally(() => setRefreshing(false));
  };

  if (loading) {
    return <Loader />;
  }

  const dashboard = data || {};

  const monthlyUsers = Object.values(
    dashboard.userRegistrationTrend || {}
  );

  const revenue = Object.values(
    dashboard.revenueTrend || {}
  );

  // TODO: Connect with backend
  const recentActivities = [];
  const recentPayments = [];
  const recentUsers = [];

  // Temporary admin object
  // Replace with logged-in admin data later
  const admin = {
    name: "Administrator",
    role: "Super Admin",
    email: "admin@gathbandhan.com",
    image:
      "https://ui-avatars.com/api/?name=Admin&background=7C3AED&color=fff",
  };

  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  return (
    <div className="space-y-6">

      {/* Dashboard Header */}
      <div className="bg-purple-50 rounded-2xl shadow-md border border-purple-100 p-6 flex flex-col lg:flex-row justify-between items-center">

        {/* Left Side */}
        <div>
          <h1 className="text-4xl font-bold text-gray-800">
            Dashboard 👋
          </h1>

          <p className="text-gray-500 mt-2 text-lg">
            Welcome back,
            <span className="font-semibold text-violet-700">
              {" "}
              {admin.name}
            </span>
          </p>

          <p className="text-sm text-gray-400 mt-1">
            Manage your Matrimony Platform efficiently.
          </p>
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-5 mt-6 lg:mt-0">

          {/* Admin Profile */}
          <div className="flex items-center gap-3 bg-white rounded-xl px-4 py-3 shadow-sm border">

            <img
              src={admin.image}
              alt="Admin"
              className="w-12 h-12 rounded-full border"
            />

            <div>
              <h3 className="font-semibold text-gray-800">
                {admin.name}
              </h3>

              <p className="text-sm text-gray-500">
                {admin.role}
              </p>
            </div>

          </div>

          {/* Refresh */}
          <button
            aria-label="Refresh dashboard"
            title="Refresh"
            onClick={refreshData}
            disabled={refreshing}
            className={`px-5 py-3 bg-violet-700 text-white rounded-xl shadow hover:bg-violet-800 transition ${
              refreshing
                ? "opacity-60 cursor-not-allowed"
                : ""
            }`}
          >
            {refreshing ? "Refreshing..." : "Refresh"}
          </button>

        </div>

      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">

        <StatsCard
          title="Total Users"
          value={dashboard.totalUsers}
          type="users"
        />

        <StatsCard
          title="Active Users"
          value={dashboard.activeUsers}
          type="active"
        />

        <StatsCard
          title="Premium Users"
          value={dashboard.activeSubscriptions}
          type="premium"
        />

        <StatsCard
          title="Revenue"
          value={`₹ ${dashboard.totalRevenue ?? 0}`}
          type="revenue"
        />

      </div>

      {/* Charts */}
            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">

              {/* Monthly Users */}
              <div className="bg-purple-50 rounded-2xl shadow-lg p-6 hover:shadow-xl transition border border-purple-100">

                <div className="flex justify-between items-center mb-4">

                  <div>
                    <h2 className="text-xl font-bold text-gray-800">
                      Monthly Users
                    </h2>

                    <p className="text-gray-500 text-sm">
                      Last 12 Months
                    </p>
                  </div>

                  <span className="bg-violet-100 text-violet-700 px-3 py-1 rounded-full text-sm">
                    +18%
                  </span>

                </div>

                <MiniChart
                  data={monthlyUsers}
                  width={650}
                  height={220}
                  labels={months}
                  color="#7C3AED"
                />

                <div className="mt-3 px-1">
                  <div className="flex items-center justify-between text-xs text-gray-500 px-2">

                    {months
                      .slice(0, monthlyUsers.length)
                      .map((m) => (
                        <span
                          key={m}
                          className="inline-block w-full text-center"
                        >
                          {m}
                        </span>
                      ))}

                  </div>
                </div>

              </div>

              {/* Revenue */}
              <div className="bg-purple-50 rounded-2xl shadow-lg p-6 hover:shadow-xl transition border border-purple-100">

                <div className="flex justify-between items-center mb-4">

                  <div>
                    <h2 className="text-xl font-bold text-gray-800">
                      Revenue
                    </h2>

                    <p className="text-gray-500 text-sm">
                      Monthly Earnings
                    </p>
                  </div>

                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                    +12%
                  </span>

                </div>

                <MiniChart
                  data={revenue}
                  width={650}
                  height={220}
                  labels={months}
                  color="#EC4899"
                />

                <div className="mt-3 px-1">
                  <div className="flex items-center justify-between text-xs text-gray-500 px-2">

                    {months
                      .slice(0, revenue.length)
                      .map((m) => (
                        <span
                          key={m}
                          className="inline-block w-full text-center"
                        >
                          {m}
                        </span>
                      ))}

                  </div>
                </div>

              </div>

            </div>

            {/* Subscription + Recent Activities */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

              <div className="bg-purple-50 rounded-2xl shadow-lg p-5 border border-purple-100">

                <h2 className="text-xl font-bold text-gray-800 mb-4">
                  Subscription Overview
                </h2>

                <SubscriptionChart height={220} />

              </div>

              <div className="bg-purple-50 rounded-2xl shadow-lg p-6 border border-purple-100">

                <div className="flex justify-between items-center mb-5">

                  <h2 className="text-2xl font-bold text-gray-800">
                    📋 Recent Activities
                  </h2>

                </div>

                {recentActivities.length === 0 ? (

                  <div className="text-center py-12 text-gray-400">
                    No recent activities found.
                  </div>

                ) : (

                  <div className="space-y-3">

                    {recentActivities.map((item) => (

                      <div
                        key={item.id}
                        className="border border-violet-100 rounded-xl p-4 hover:bg-violet-50 transition"
                      >

                        <p>{item.text}</p>

                        <small className="text-gray-500">
                          {item.time}
                        </small>

                      </div>

                    ))}

                  </div>

                )}

              </div>

            </div>

            {/* Recent Payments + Recent Users */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

              {/* Recent Payments */}
              <div className="bg-purple-50 rounded-2xl shadow-lg p-6 border border-purple-100">

                <h2 className="text-2xl font-bold text-gray-800 mb-5">
                  💳 Recent Payments
                </h2>

                {recentPayments.length === 0 ? (

                  <div className="text-center py-12 text-gray-400">
                    No recent payments found.
                  </div>

                ) : (

                  <div className="space-y-3">

                    {recentPayments.map((item) => (

                      <div
                        key={item.id}
                        className="flex justify-between items-center border border-violet-100 rounded-xl p-4 hover:bg-violet-50 transition"
                      >

                        <div>

                          <h4>{item.user}</h4>

                          <small
                            className={`font-semibold ${
                              item.status === "Paid"
                                ? "text-green-600"
                                : "text-red-500"
                            }`}
                          >
                            {item.status}
                          </small>

                        </div>

                        <div className="text-right">

                          <p className="font-bold">
                            ₹{item.amount}
                          </p>

                          <small>
                            {item.date}
                          </small>

                        </div>

                      </div>

                    ))}

                  </div>

                )}

              </div>

              {/* Recent Users */}
              <div className="bg-purple-50 rounded-2xl shadow-lg p-6 border border-purple-100">

                <div className="flex justify-between items-center mb-6">

                  <h2 className="text-2xl font-bold text-gray-800">
                    👥 Recent Users
                  </h2>

                  <button className="text-violet-700 hover:underline font-semibold">
                    View All
                  </button>

                </div>

                {recentUsers.length === 0 ? (

                  <div className="text-center py-12 text-gray-400">
                    No recent users found.
                  </div>

                ) : (

                  <div className="space-y-4">

                    {recentUsers.map((user) => (

                      <div
                        key={user.id}
                        className="flex items-center justify-between border-b pb-4"
                      >

                        <div className="flex items-center gap-4">

                          <img
                            src={user.photo}
                            alt={user.name}
                            className="w-12 h-12 rounded-full"
                          />

                          <div>

                            <h3 className="font-semibold">
                              {user.name}
                            </h3>

                            <p className="text-sm text-gray-500">
                              {user.membership}
                            </p>

                          </div>

                        </div>

                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">

                          {user.status}

                        </span>

                      </div>

                    ))}

                  </div>

                )}

              </div>

            </div>
                  {/* Quick Actions */}
                  <div className="bg-purple-50 rounded-2xl shadow-lg p-6 border border-purple-100">

                    <div className="flex justify-between items-center mb-6">

                      <h2 className="text-2xl font-bold text-gray-800">
                        ⚡ Quick Actions
                      </h2>

                      <span className="text-sm text-gray-500">
                        Frequently Used Modules
                      </span>

                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-5">

                      {/* Users */}
                      <button className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl p-5 transition-all duration-300 shadow hover:shadow-lg">

                        <div className="text-3xl">👥</div>

                        <p className="mt-3 font-semibold">
                          Users
                        </p>

                      </button>

                      {/* Payments */}
                      <button className="bg-pink-600 hover:bg-pink-700 text-white rounded-xl p-5 transition-all duration-300 shadow hover:shadow-lg">

                        <div className="text-3xl">💳</div>

                        <p className="mt-3 font-semibold">
                          Payments
                        </p>

                      </button>

                      {/* Notifications */}
                      <button className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl p-5 transition-all duration-300 shadow hover:shadow-lg">

                        <div className="text-3xl">🔔</div>

                        <p className="mt-3 font-semibold">
                          Notifications
                        </p>

                      </button>

                      {/* Master Data */}
                      <button className="bg-green-600 hover:bg-green-700 text-white rounded-xl p-5 transition-all duration-300 shadow hover:shadow-lg">

                        <div className="text-3xl">🗂️</div>

                        <p className="mt-3 font-semibold">
                          Master Data
                        </p>

                      </button>

                    </div>

                  </div>

                </div>
              );
            }